# import math
# #convertir tipos de datos con float intentara coonvertir el texto a decimal
# proteina = float(input("Ingrese los gr de proteínas: \n"))
# carbohidratos = float(input("Ingrese los gr de carbohidratos: \n"))
# grasa = float(input("Ingrese los gramos de grasas: \n"))
# grados_alcoholicos = float(input("Ingrese los grados alcoholicos: \n"))

# # calorias = 4 * (proteina + carbohidratos) + 9 * grasa
# calorias = 4 * (proteina + carbohidratos) + 9 * grasa + grados_alcoholicos*7

# print(f'Las calorías totales del producto son: {math.ceil(calorias)}')


# function nombre_funcion(){

# }

def nombre():
    print("hola soy una funcion")
#llamado a la funcion
# nombre()
