import os
# import pandas as pd
# import math

# from math import sqrt #es mas optimo 
import math as m

print(os.getcwd())
print(m.factorial(3))
print(m.sqrt(4))