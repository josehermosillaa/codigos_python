nombre = input("Ingrese su Nombre: ")
#conexion con la rae
# preguntara la palabra existe?
# print(f"su nombre es {nombre}")
edad = input("Ingrese Edad: ")
ocupacion = input("Ingresa Ocupacion")

mensaje = f""" 
Mi nombre es {nombre} ,
mi edad es {edad},
y mi
 ocupación 
    es {ocupacion}"""

print(mensaje)