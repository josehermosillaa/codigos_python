"""
operacion entre numeros enteros
"""
# print("la division entera sera",5//2)
# print("el resto sera",5%2)
# print("tipo de dato div entera",type(5//2))
# print("tipo de dato operacion resto",type(5%2))

# print(1+1) #2

# print("1"+"1") # 11

# # 1 1

#etiqueta o nombre de variable
frase = "Hola MunDo CoMO Estan"
#
# print(frase.count("o"))
# print(frase.count("O"))


# #metodo count cuando existen O mayusculas
# frase_mayuscula = frase.upper()
# print(frase_mayuscula.count("O"))
#queda pendiente como hacerlo con el metodo lower

# #metodo uppercase
# print(frase.upper())
# #metodo  LowerCase ( minuscula)
# print(frase.lower())


# #metodo Title
# frase = "Hola MunDo CoMO Estan"
# print(frase.title())

# #metodo len
# print(len(frase))

# lista = ["Pera", "Palta", "Mantequilla", "Queso", "Pan"]

# print("Mi lista de supermercado:",",\n".join(lista))

# #"CONSTANTES" -> IGUAL PUEDE SER REASIGNADO
# NUMERO = 3
# print(NUMERO)

# NUMERO = "PATATA"
# print(NUMERO)

a = 3
a = a + 3

nombre = "Jose"
apellido = "Hermosilla"
apellido_2 = "Avila"
#primer metodo
print("Mi nombre es {} {} {}".format(nombre, apellido, apellido_2))
#segundo metodo
print(f"Mi nombre es {nombre} {apellido} {apellido_2}")

print(f"{10/3:.4f}")

#f-string