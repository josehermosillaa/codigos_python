# # #numero entero
# print(type(10)) # INT
# # #numero decimal
# # print(3.2)

# print(type(3.2*10))
# print(10+2.0)
# print(4/2)



# #string
# print("hola soy un texto")

# print('Hola soy otro texto')





#Booleano
#esta se generan cuando hagamos operaciones condicionales
# mayor, menor que, mayor igual menor o igual que, igual o distintos
# <>, <= >=,  == !=
# print(False)

# print(True)

print("mi numero de telefono es ",964152485)